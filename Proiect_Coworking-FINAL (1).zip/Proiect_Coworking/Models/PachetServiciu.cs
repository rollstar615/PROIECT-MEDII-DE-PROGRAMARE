using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Proiect_Coworking.Models
{
    /// <summary>
    /// Pachet de servicii (ex. "Basic", "Pro", "Sala cu videoproiector") care poate fi ales la o rezervare.
    /// </summary>
    public class PachetServiciu
    {
        public int PachetServiciuID { get; set; }

        [Required]
        [StringLength(80, MinimumLength = 3)]
        [DisplayName("Pachet")]
        public string Nume { get; set; } = string.Empty;

        [StringLength(250)]
        [DisplayName("Descriere")]
        public string? Descriere { get; set; }

        [Range(0, 9999)]
        [Column(TypeName = "decimal(8,2)")]
        [DisplayName("Pret / ora")]
        public decimal PretPeOra { get; set; }

        // Relatii
        public ICollection<Rezervare> Rezervari { get; set; } = new List<Rezervare>();
    }
}
