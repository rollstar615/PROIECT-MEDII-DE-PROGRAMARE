using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Proiect_Coworking.Models
{
    /// <summary>
    /// Sala / camera dintr-o locatie de coworking.
    /// </summary>
    public class Sala
    {
        public int SalaID { get; set; }

        [Required]
        [StringLength(80, MinimumLength = 2)]
        [DisplayName("Denumire sala")]
        public string Nume { get; set; } = string.Empty;

        [Range(1, 200)]
        [DisplayName("Capacitate")]
        public int Capacitate { get; set; }

        [StringLength(120)]
        [DisplayName("Dotari")]
        public string? Dotari { get; set; } // ex. "TV, Whiteboard, Proiector"

        // Relatii
        [DisplayName("Locatie")]
        public int LocatieID { get; set; }
        public Locatie? Locatie { get; set; }

        public ICollection<Rezervare> Rezervari { get; set; } = new List<Rezervare>();
    }
}
