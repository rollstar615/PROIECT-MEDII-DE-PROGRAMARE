using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Proiect_Coworking.Models
{
    /// <summary>
    /// Rezervare sala de coworking.
    /// </summary>
    public class Rezervare
    {
        public int RezervareID { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        [DisplayName("Data si ora inceput")]
        public DateTime DataOraInceput { get; set; }

        [Range(1, 12)]
        [DisplayName("Durata (ore)")]
        public int DurataOre { get; set; } = 1;

        [Required]
        [StringLength(30)]
        [DisplayName("Status")]
        public string Status { get; set; } = "Nou"; // Nou / Confirmata / Anulata

        [StringLength(250)]
        [DisplayName("Observatii")]
        public string? Observatii { get; set; }

        // Relatii
        [DisplayName("Sala")]
        public int SalaID { get; set; }
        public Sala? Sala { get; set; }

        [DisplayName("Membru")]
        public int MembruID { get; set; }
        public Membru? Membru { get; set; }

        [DisplayName("Pachet")]
        public int PachetServiciuID { get; set; }
        public PachetServiciu? PachetServiciu { get; set; }
    }
}
