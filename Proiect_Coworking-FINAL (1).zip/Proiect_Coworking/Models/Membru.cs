using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Proiect_Coworking.Models
{
    /// <summary>
    /// Membru / client care poate face rezervari.
    /// </summary>
    public class Membru
    {
        public int MembruID { get; set; }

        [Required]
        [StringLength(120, MinimumLength = 3)]
        [DisplayName("Nume")]
        public string Nume { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [StringLength(120)]
        [DisplayName("Email")]
        public string Email { get; set; } = string.Empty;

        [Phone]
        [StringLength(30)]
        [DisplayName("Telefon")]
        public string? Telefon { get; set; }

        [DataType(DataType.Date)]
        [DisplayName("Data inscrierii")]
        public DateTime DataInscriere { get; set; } = DateTime.Today;

        // Relatii
        public ICollection<Rezervare> Rezervari { get; set; } = new List<Rezervare>();
    }
}
