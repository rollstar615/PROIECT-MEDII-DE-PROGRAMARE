using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Sali
{
    public class CreateModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public CreateModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            ViewData["LocatieID"] = new SelectList(_context.Locatie, "LocatieID", "Nume");
            return Page();
        }

        [BindProperty]
        public Sala Sala { get; set; } = new();

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                ViewData["LocatieID"] = new SelectList(_context.Locatie, "LocatieID", "Nume");
                return Page();
            }

            _context.Sala.Add(Sala);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
