using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Sali
{
    public class EditModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public EditModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Sala Sala { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null) return NotFound();

            var sala = await _context.Sala.FirstOrDefaultAsync(m => m.SalaID == id);
            if (sala == null) return NotFound();

            Sala = sala;
            ViewData["LocatieID"] = new SelectList(_context.Locatie, "LocatieID", "Nume");
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                ViewData["LocatieID"] = new SelectList(_context.Locatie, "LocatieID", "Nume");
                return Page();
            }

            _context.Attach(Sala).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Sala.Any(e => e.SalaID == Sala.SalaID))
                    return NotFound();
                throw;
            }

            return RedirectToPage("./Index");
        }
    }
}
