using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Membri
{
    public class IndexModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public IndexModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        public IList<Membru> Membri { get; set; } = default!;

        public async Task OnGetAsync()
        {
            Membri = await _context.Membru.ToListAsync();
        }
    }
}
