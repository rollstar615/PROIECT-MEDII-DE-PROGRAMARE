using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Membri
{
    public class EditModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public EditModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Membru Membru { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null) return NotFound();

            var membru = await _context.Membru.FirstOrDefaultAsync(m => m.MembruID == id);
            if (membru == null) return NotFound();

            Membru = membru;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            _context.Attach(Membru).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Membru.Any(e => e.MembruID == Membru.MembruID))
                    return NotFound();
                throw;
            }

            return RedirectToPage("./Index");
        }
    }
}
