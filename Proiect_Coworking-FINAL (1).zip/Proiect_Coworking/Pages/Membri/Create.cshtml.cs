using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Membri
{
    public class CreateModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public CreateModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Membru Membru { get; set; } = new();

        public void OnGet() { }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            _context.Membru.Add(Membru);
            await _context.SaveChangesAsync();
            return RedirectToPage("./Index");
        }
    }
}
