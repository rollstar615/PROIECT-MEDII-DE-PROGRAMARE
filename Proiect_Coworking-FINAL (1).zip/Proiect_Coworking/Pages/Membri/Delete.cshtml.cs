using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Membri
{
    public class DeleteModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public DeleteModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Membru Membru { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null) return NotFound();
            var membru = await _context.Membru.FirstOrDefaultAsync(m => m.MembruID == id);
            if (membru == null) return NotFound();
            Membru = membru;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null) return NotFound();
            var membru = await _context.Membru.FindAsync(id);
            if (membru != null)
            {
                _context.Membru.Remove(membru);
                await _context.SaveChangesAsync();
            }
            return RedirectToPage("./Index");
        }
    }
}
