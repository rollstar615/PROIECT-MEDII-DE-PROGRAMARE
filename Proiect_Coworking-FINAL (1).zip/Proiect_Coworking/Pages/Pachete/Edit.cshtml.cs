﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Pachete
{
    public class EditModel : PageModel
    {
        private readonly Proiect_Coworking.Data.Proiect_CoworkingContext _context;

        public EditModel(Proiect_Coworking.Data.Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public PachetServiciu PachetServiciu { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.PachetServiciu == null)
            {
                return NotFound();
            }

            var pachet =  await _context.PachetServiciu.FirstOrDefaultAsync(m => m.PachetServiciuID == id);
            if (pachet == null)
            {
                return NotFound();
            }
            PachetServiciu = pachet;
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(PachetServiciu).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PachetExists(PachetServiciu.PachetServiciuID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool PachetExists(int id)
        {
          return _context.PachetServiciu.Any(e => e.PachetServiciuID == id);
        }
    }
}
