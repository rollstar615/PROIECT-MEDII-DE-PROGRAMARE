﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Pachete
{
    public class IndexModel : PageModel
    {
        private readonly Proiect_Coworking.Data.Proiect_CoworkingContext _context;

        public IndexModel(Proiect_Coworking.Data.Proiect_CoworkingContext context)
        {
            _context = context;
        }

        public IList<PachetServiciu> PachetServiciu { get;set; } = default!;

        public async Task OnGetAsync()
        {
                PachetServiciu = await _context.PachetServiciu.ToListAsync();
            
        }
    }
}
