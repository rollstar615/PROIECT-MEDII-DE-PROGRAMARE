﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Pachete
{
    public class DeleteModel : PageModel
    {
        private readonly Proiect_Coworking.Data.Proiect_CoworkingContext _context;

        public DeleteModel(Proiect_Coworking.Data.Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
      public PachetServiciu PachetServiciu { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.PachetServiciu == null)
            {
                return NotFound();
            }

            var serviciu = await _context.PachetServiciu
                .Include(s => s.Descriere)
                .FirstOrDefaultAsync(m => m.PachetServiciuID == id);

            if (serviciu == null)
            {
                return NotFound();
            }
            else 
            {
                PachetServiciu = serviciu;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.PachetServiciu == null)
            {
                return NotFound();
            }
            var serviciu = await _context.PachetServiciu.FindAsync(id);

            if (serviciu != null)
            {
                PachetServiciu = serviciu;
                _context.PachetServiciu.Remove(PachetServiciu);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
