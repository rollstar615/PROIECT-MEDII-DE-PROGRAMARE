using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Rezervari
{
    public class IndexModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public IndexModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        public IList<Rezervare> Rezervari { get; set; } = default!;

        public async Task OnGetAsync()
        {
            Rezervari = await _context.Rezervare
                .Include(p => p.Sala)
                .Include(p => p.Membru)
                .Include(p => p.PachetServiciu)
                .ToListAsync();
        }
    }
}
