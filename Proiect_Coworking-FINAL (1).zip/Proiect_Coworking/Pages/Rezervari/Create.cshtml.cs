using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Rezervari
{
    public class CreateModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public CreateModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            ViewData["SalaID"] = new SelectList(_context.Sala, "SalaID", "Nume");
            ViewData["MembruID"] = new SelectList(_context.Membru, "MembruID", "Nume");
            ViewData["PachetServiciuID"] = new SelectList(_context.PachetServiciu, "PachetServiciuID", "Nume");
            return Page();
        }

        [BindProperty]
        public Rezervare Rezervare { get; set; } = new() { DataOraInceput = DateTime.Now };

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                ViewData["SalaID"] = new SelectList(_context.Sala, "SalaID", "Nume");
                ViewData["MembruID"] = new SelectList(_context.Membru, "MembruID", "Nume");
                ViewData["PachetServiciuID"] = new SelectList(_context.PachetServiciu, "PachetServiciuID", "Nume");
                return Page();
            }

            _context.Rezervare.Add(Rezervare);
            await _context.SaveChangesAsync();
            return RedirectToPage("./Index");
        }
    }
}
