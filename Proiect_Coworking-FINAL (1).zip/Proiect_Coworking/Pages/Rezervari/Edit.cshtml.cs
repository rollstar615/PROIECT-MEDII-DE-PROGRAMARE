using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Rezervari
{
    public class EditModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public EditModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Rezervare Rezervare { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null) return NotFound();

            var rezervare = await _context.Rezervare.FirstOrDefaultAsync(r => r.RezervareID == id);
            if (rezervare == null) return NotFound();

            Rezervare = rezervare;
            ViewData["SalaID"] = new SelectList(_context.Sala, "SalaID", "Nume");
            ViewData["MembruID"] = new SelectList(_context.Membru, "MembruID", "Nume");
            ViewData["PachetServiciuID"] = new SelectList(_context.PachetServiciu, "PachetServiciuID", "Nume");
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                ViewData["SalaID"] = new SelectList(_context.Sala, "SalaID", "Nume");
                ViewData["MembruID"] = new SelectList(_context.Membru, "MembruID", "Nume");
                ViewData["PachetServiciuID"] = new SelectList(_context.PachetServiciu, "PachetServiciuID", "Nume");
                return Page();
            }

            _context.Attach(Rezervare).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Rezervare.Any(e => e.RezervareID == Rezervare.RezervareID))
                    return NotFound();
                throw;
            }

            return RedirectToPage("./Index");
        }
    }
}
