using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Coworking.Data;
using Proiect_Coworking.Models;

namespace Proiect_Coworking.Pages.Rezervari
{
    public class DeleteModel : PageModel
    {
        private readonly Proiect_CoworkingContext _context;

        public DeleteModel(Proiect_CoworkingContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Rezervare Rezervare { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null) return NotFound();

            var rezervare = await _context.Rezervare
                .Include(p => p.Sala)
                .Include(p => p.Membru)
                .Include(p => p.PachetServiciu)
                .FirstOrDefaultAsync(p => p.RezervareID == id);

            if (rezervare == null) return NotFound();
            Rezervare = rezervare;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null) return NotFound();

            var rezervare = await _context.Rezervare.FindAsync(id);
            if (rezervare != null)
            {
                _context.Rezervare.Remove(rezervare);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
